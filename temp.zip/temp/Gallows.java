import javax.swing.*;
import java.awt.*;

public class Gallows extends JPanel {

    private static final int MAX_BODY_PARTS = 6;
    private int numBodyParts;
    private ImageIcon[] gallowsStages;

    public Gallows() {
        numBodyParts = 0;
        gallowsStages = new ImageIcon[MAX_BODY_PARTS + 1]; // +1 for the complete hangman

        // Load images representing different stages of the gallows (head, torso, etc.)
        for (int i = 0; i < gallowsStages.length; i++) {
            gallowsStages[i] = new ImageIcon("gallows_" + i + ".png");
        }

        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(200, 200));
    }

    public void addBodyPart() {
        if (numBodyParts < MAX_BODY_PARTS) {
            numBodyParts++;
            repaint();
        }
    }

    public void gameOver(boolean win) {
        // If win is true, display a winning message (optional)
        // Otherwise, display a losing message (optional)
        repaint();
    }

    public void reset() {
        numBodyParts = 0;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (numBodyParts > 0) {
            gallowsStages[numBodyParts].paintIcon(this, g, 0, 0);
        } else {
            // Draw the base of the gallows (optional)
        }
    }
}
